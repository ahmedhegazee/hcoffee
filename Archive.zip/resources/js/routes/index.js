import Home from "../pages/Home.vue";

export const routes = [
    {
        name: "home",
        path: "/",
        component: Home,
    },
];
