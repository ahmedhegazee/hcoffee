@extends('layouts.dashboard')

@section('content')
<div class="container">

</div>
@endsection
@push('scripts')
<script src="{{ asset('adminlte/js/Chart.min.js') }}"></script>
<script src="{{ asset('adminlte/js/demo.js') }}"></script>
<script src="{{ asset('adminlte/js/dashboard3.js') }}"></script>
@endpush
