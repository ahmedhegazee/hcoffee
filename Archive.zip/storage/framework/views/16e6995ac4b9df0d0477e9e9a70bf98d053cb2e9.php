<?php $__env->startSection('content'); ?>
<?php if(session('errorMessage')): ?>
<div class="alert alert-danger">
    <?php echo e(session('errorMessage')); ?>

</div>
<?php endif; ?>
<?php if(session('successMessage')): ?>
<div class="alert alert-success">
    <?php echo e(session('successMessage')); ?>

</div>
<?php endif; ?>
<form action="<?php echo e(route('admin.interval.index')); ?>" method="GET">
    <select name="type">
        <option value="" disabled>اختر الفترة</option>
        <option value="0">الفترة الاولى</option>
        <option value="1">الفترة الثانية</option>
    </select>
    <select name="status">
        <option value="" disabled>اختر حالة الفترة</option>
        <option value="0">غير مكتمل</option>
        <option value="1">مكتمل</option>
    </select>
    <input type="date" name="start_date" placeholder="">
    <label for="">تاريخ البداية</label>

    <input type="date" name="start_date" placeholder="">
    <label for="">تاريخ النهاية</label>

    <button class="btn btn-primary">فلتر</button>
</form>
<table class="table table-hover text-nowrap">
    <thead>
        <tr>
            <th>التاريخ</th>
            <th>الفترة</th>
            <th>مكتمل</th>
            <th>اقصى عدد للحاضرين</th>
            <th>عدد الحاجزين</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $intervals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e($interval->date); ?>

            </td>
            <td><?php echo e($interval->type); ?></td>
            <td><?php echo e($interval->is_completed); ?></td>
            <td>
                <form action="<?php echo e(route('admin.interval.update',$interval->id)); ?>" method="POST">
                    <input type="number" name="max_guests_count" value="<?php echo e($interval->max_guests_count); ?>"
                        min="<?php echo e($interval->guests_count); ?>" id="">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-secondary">حفظ</button>
                    <?php echo method_field("put"); ?>
                </form>

            </td>
            <td><?php echo e($interval->guests_count); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="row justify-content-center">
    <?php echo e($intervals->appends(['start_date'=>request('start_date'),'end_date'=>request('end_date'),'type'=>request('type'),'status'=>request('status')])); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Hegazy/lar/hcoffee/resources/views/dashboard/intervals/index.blade.php ENDPATH**/ ?>