<?php $__env->startSection('content'); ?>

<table class="table table-hover text-nowrap">
    <thead>
        <tr>
            <th>الاسم</th>
            <th>رقم الجوال</th>
            <th>حالة الدفع</th>
            <th>المبلغ الاجمالي</th>
            <th>التاريخ</th>
            <th>عدد الاشخاص</th>
            <th>الفترة</th>
            <th>الملاحظات</th>
            <th>حالة الحجز</th>
            <th>الاوامر</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($reservation->name); ?></td>
            <td><?php echo e($reservation->phone); ?></td>
            <td><?php echo e($reservation->payment_status); ?></td>
            <td><?php echo e($reservation->total_amount); ?></td>
            <td><?php echo e($reservation->date); ?></td>
            <td><?php echo e($reservation->guests_count); ?></td>
            <td><?php echo e($reservation->interval); ?></td>
            <td><?php echo e($reservation->notes); ?></td>
            <td><?php echo e($reservation->is_accepted); ?></td>
            <td>
                <select onchange="changeReservationStatus(<?php echo e($reservation->id); ?>)"
                    id="reservation-status-<?php echo e($reservation->id); ?>">
                    <option disabled> اختر حالة الحجز</option>
                    <option value="0">في الانتظار</option>
                    <option value="1">تمت الموافقة</option>
                    <option value="2">تم الالغاء</option>
                </select>
                <a href="#" class="btn btn-success"
                    onclick="event.preventDefault();updateRecord(<?php echo e($reservation->id); ?>)"><i class="fas fa-edit"></i>
                    تغيير حالة الحجز</a>
                <form id="update-form-<?php echo e($reservation->id); ?>"
                    action="<?php echo e(route('admin.reservation.update',$reservation->id)); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                    <input type="number" value="0" id="update-<?php echo e($reservation->id); ?>" name="is_accepted">
                    <?php echo method_field("put"); ?>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="row justify-content-center">
    <?php echo e($reservations->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('partials.update-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Hegazy/lar/hcoffee/resources/views/dashboard/reservations/index.blade.php ENDPATH**/ ?>