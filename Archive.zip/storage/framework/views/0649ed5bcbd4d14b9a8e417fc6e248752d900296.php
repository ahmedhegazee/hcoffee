<?php $__env->startSection('content'); ?>
<table class="table table-hover text-nowrap">
    <thead>
        <tr>
            <th>الاسم</th>
            <th>القيمة</th>

        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($setting->name); ?></td>

            <td>
                <form id="update-form-<?php echo e($setting->id); ?>" action="<?php echo e(route('admin.setting.update',$setting->id)); ?>"
                    method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="number" value="<?php echo e($setting->value); ?>" name="value">
                    <?php echo method_field("put"); ?>
                    <button class="btn btn-secondary">حفظ</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="row justify-content-center">
    <?php echo e($settings->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('partials.update-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Hegazy/lar/hcoffee/resources/views/dashboard/settings/index.blade.php ENDPATH**/ ?>